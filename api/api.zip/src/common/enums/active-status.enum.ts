export enum IsActiveStatusEnum {
  disabled = 0,
  enabled = 1,
}
