export enum AreaBudgetSourceEnums {
  CAPITAL = "Capital",
  REVENUE = "Revenue",
}
