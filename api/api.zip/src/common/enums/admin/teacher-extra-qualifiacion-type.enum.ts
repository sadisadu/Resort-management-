export enum TeacherExtraQualEnum {
  EMAM = "EMAM",
  MUAZZIN = "MUAZZIN",
  OTHERS = "OTHERS",
}
