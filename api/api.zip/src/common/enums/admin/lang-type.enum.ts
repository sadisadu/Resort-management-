export enum LangTypeEnum {
  ENGLISH = "en",
  BANGLA = "bn",
}
