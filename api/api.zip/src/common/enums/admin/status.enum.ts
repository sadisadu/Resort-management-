export enum EnStatusTypeEnum {
  ACTIVE = "Active",
  INACTIVE = "Inactive",
}

export enum BnStatusTypeEnum {
  ACTIVE = "সক্রিয়",
  INACTIVE = "নিষ্ক্রিয়",
}
