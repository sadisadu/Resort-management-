export enum TourPlanningStatus {
  PENDING = "Pending",
  APPROVED = "Approve",
  REJECTED = "Reject",
}

export enum TourPlanningApprovalStatus {
  PENDING = "Pending",
  APPROVED = "Approve",
  FORWARD = "Forward",
  REJECTED = "Reject",
}
