export enum AdvanceReportSearchTypeEnums {
  EMPLOYEE = "Employee",
  TEACHER = "Teacher",
  STUDENT = "Student",
}
