export enum EExcelColumnType {
  STRING = "string",
  DATE = "date",
  NUMBER = "number",
}
