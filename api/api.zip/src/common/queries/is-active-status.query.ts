import { IsActiveStatusEnum } from "../enums/active-status.enum";

export const isActive = { status: IsActiveStatusEnum.enabled };
