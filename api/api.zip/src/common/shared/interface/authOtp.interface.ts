export interface IUserEmailOtpRequest {
  token: string;
  otp: string;
}
