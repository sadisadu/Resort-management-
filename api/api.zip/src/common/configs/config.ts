export const ADMIN_JWT_SECRET =
  process.env.JWT_SECRET || "Simec-System@123456?";
