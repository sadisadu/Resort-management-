export class MailLogDto {
  success: any;
  message: String;
  error: any;
}
