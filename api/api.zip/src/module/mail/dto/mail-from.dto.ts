// import { IsDefined, IsEmail, IsNotEmpty, IsString } from 'class-validator';

// export class MailFromDto {
//   @IsDefined()
//   @IsNotEmpty()
//   @IsString()
//   name: string;

//   @IsDefined()
//   @IsNotEmpty()
//   @IsEmail()
//   address: string;
// }
